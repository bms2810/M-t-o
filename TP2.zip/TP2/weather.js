fetch("temperatures_2023.json")
  .then((response) => {
    return response.json();
  })
  .then((meteo) => {
    const d = new Date().toLocaleDateString();
    let text = d.toString();
    date.innerHTML = d;
   
   
    for (let index = 0; index < meteo.temperatures.length; index++) {
      if (meteo.temperatures[index].DateDuJour == text) {

       
        let TempDuJour = document.getElementById("TempDuJour");
        let TempMax = document.getElementById("TempMax");
        let TempMin = document.getElementById("TempMin");


        TempDuJour.innerHTML = meteo.temperatures[index].TempDuJour;
        TempMax.innerHTML = "Max: " + meteo.temperatures[index].TempMax;
        TempMin.innerHTML = "Min: " + meteo.temperatures[index].TempMin;
      

        let jour1 = document.getElementById("jour1");
        let TempDuJour1 = document.getElementById("TempDuJour1");
       
        let TempMax1 = document.getElementById("TempMax1");
        let TempMin1 = document.getElementById("TempMin1");
        
        jour1.innerHTML = "Le : "+d;
        TempDuJour1.innerHTML ="Temp du jour: "+ meteo.temperatures[index].TempDuJour+"° C";
        TempMax1.innerHTML = "Max: " + meteo.temperatures[index].TempMax+"° C";
        TempMin1.innerHTML = "Min: " + meteo.temperatures[index].TempMin+"° C";
        //         // *******************************************************
        
        let jour2 = document.getElementById("jour2");
        let TempDuJour2 = document.getElementById("TempDuJour2");
        let TempMax2 = document.getElementById("TempMax2");
        let TempMin2 = document.getElementById("TempMin2");
        
        jour2.innerHTML = "Le : "+meteo.temperatures[index+1].DateDuJour;
        TempDuJour2.innerHTML ="Temp du jour: "+ meteo.temperatures[index+1].TempDuJour+"° C";
        TempMax2.innerHTML = "Max: " + meteo.temperatures[index+1].TempMax+"° C";
        TempMin2.innerHTML = "Min: " + meteo.temperatures[index+1].TempMin+"° C";
                // *******************************************************

        let jour3 = document.getElementById("jour3");
        let TempDuJour3 = document.getElementById("TempDuJour3");
        let TempMax3 = document.getElementById("TempMax3");
        let TempMin3 = document.getElementById("TempMin3");
        
        jour3.innerHTML = "Le : "+meteo.temperatures[index+2].DateDuJour;
        TempDuJour3.innerHTML ="Temp du jour: "+ meteo.temperatures[index+2].TempDuJour+"° C";
        TempMax3.innerHTML = "Max: " + meteo.temperatures[index+2].TempMax+"° C";
        TempMin3.innerHTML = "Min: " + meteo.temperatures[index+2].TempMin+"° C";
         // *******************************************************
         let jour4 = document.getElementById("jour4");
         let TempDuJour4 = document.getElementById("TempDuJour4");
         let TempMax4 = document.getElementById("TempMax4");
         let TempMin4 = document.getElementById("TempMin4");
         
         jour4.innerHTML = "Le : "+meteo.temperatures[index+3].DateDuJour;
         TempDuJour4.innerHTML ="Temp du jour: "+ meteo.temperatures[index+3].TempDuJour+"° C";
         TempMax4.innerHTML = "Max: " + meteo.temperatures[index+3].TempMax+"° C";
         TempMin4.innerHTML = "Min: " + meteo.temperatures[index+3].TempMin+"° C";
          // *******************************************************
          let jour5 = document.getElementById("jour5");
         let TempDuJour5 = document.getElementById("TempDuJour5");
         let TempMax5 = document.getElementById("TempMax5");
         let TempMin5 = document.getElementById("TempMin5");
         
         jour5.innerHTML = "Le : "+meteo.temperatures[index+4].DateDuJour;
         TempDuJour5.innerHTML ="Temp du jour: "+ meteo.temperatures[index+4].TempDuJour+"° C";
         TempMax5.innerHTML = "Max: " + meteo.temperatures[index+4].TempMax+"° C";
         TempMin5.innerHTML = "Min: " + meteo.temperatures[index+4].TempMin+"° C";
           // *******************************************************
           let jour6= document.getElementById("jour6");
         let TempDuJour6 = document.getElementById("TempDuJour6");
         let TempMax6 = document.getElementById("TempMax6");
         let TempMin6 = document.getElementById("TempMin6");
         
         jour6.innerHTML = "Le : "+meteo.temperatures[index+5].DateDuJour;
         TempDuJour6.innerHTML ="Temp du jour: "+ meteo.temperatures[index+5].TempDuJour+"° C";
         TempMax6.innerHTML = "Max: " + meteo.temperatures[index+5].TempMax+"° C";
         TempMin6.innerHTML = "Min: " + meteo.temperatures[index+5].TempMin+"° C";
            // *******************************************************
            let jour7= document.getElementById("jour7");
         let TempDuJour7 = document.getElementById("TempDuJour7");
         let TempMax7 = document.getElementById("TempMax7");
         let TempMin7 = document.getElementById("TempMin7");
         
         jour7.innerHTML = "Le : "+meteo.temperatures[index+6].DateDuJour;
         TempDuJour7.innerHTML ="Temp du jour: "+ meteo.temperatures[index+6].TempDuJour+"° C";
         TempMax7.innerHTML = "Max: " + meteo.temperatures[index+6].TempMax+"° C";
         TempMin7.innerHTML = "Min: " + meteo.temperatures[index+6].TempMin+"° C";
             // *******************************************************
         let jour8= document.getElementById("jour8");
         let TempDuJour8 = document.getElementById("TempDuJour8");
         let TempMax8 = document.getElementById("TempMax8");
         let TempMin8 = document.getElementById("TempMin8");
         
         jour8.innerHTML = "Le : "+meteo.temperatures[index+7].DateDuJour;
         TempDuJour8.innerHTML ="Temp du jour: "+ meteo.temperatures[index+7].TempDuJour+"° C";
         TempMax8.innerHTML = "Max: " + meteo.temperatures[index+7].TempMax+"° C";
         TempMin8.innerHTML = "Min: " + meteo.temperatures[index+7].TempMin+"° C";
              // *******************************************************
         let jour9= document.getElementById("jour9");
         let TempDuJour9 = document.getElementById("TempDuJour9");
         let TempMax9 = document.getElementById("TempMax9");
         let TempMin9 = document.getElementById("TempMin9");
         
         jour9.innerHTML = "Le : "+meteo.temperatures[index+8].DateDuJour;
         TempDuJour9.innerHTML ="Temp du jour: "+ meteo.temperatures[index+8].TempDuJour+"° C";
         TempMax9.innerHTML = "Max: " + meteo.temperatures[index+8].TempMax+"° C";
         TempMin9.innerHTML = "Min: " + meteo.temperatures[index+8].TempMin+"° C";
               // *******************************************************
         let jour10= document.getElementById("jour10");
         let TempDuJour10 = document.getElementById("TempDuJou10");
         let TempMax10 = document.getElementById("TempMax10");
         let TempMin10 = document.getElementById("TempMin10");

         jour10.innerHTML = "Le : "+meteo.temperatures[index+9].DateDuJour;
         TempDuJour10.innerHTML ="Temp du jour: "+ meteo.temperatures[index+9].TempDuJour+"° C";
         TempMax10.innerHTML = "Max: " + meteo.temperatures[index+9].TempMax+"° C";
         TempMin10.innerHTML = "Min: " + meteo.temperatures[index+9].TempMin+"° C";
                // *******************************************************
        let jour11= document.getElementById("jour11");
         let TempDuJour11 = document.getElementById("TempDuJour11");
         let TempMax11 = document.getElementById("TempMax11");
         let TempMin11 = document.getElementById("TempMin11");

         jour11.innerHTML = "Le : "+meteo.temperatures[index+10].DateDuJour;
         TempDuJour11.innerHTML ="Temp du jour: "+ meteo.temperatures[index+10].TempDuJour+"° C";
         TempMax11.innerHTML = "Max: " + meteo.temperatures[index+10].TempMax+"° C";
         TempMin11.innerHTML = "Min: " + meteo.temperatures[index+10].TempMin+"° C";
                 // *******************************************************
         let jour12= document.getElementById("jour12");
         let TempDuJour12= document.getElementById("TempDuJour12");
         let TempMax12 = document.getElementById("TempMax12");
         let TempMin12 = document.getElementById("TempMin12");

         jour12.innerHTML = "Le : "+meteo.temperatures[index+11].DateDuJour;
         TempDuJour12.innerHTML ="Temp du jour: "+ meteo.temperatures[index+11].TempDuJour+"° C";
         TempMax12.innerHTML = "Max: " + meteo.temperatures[index+11].TempMax+"° C";
         TempMin12.innerHTML = "Min: " + meteo.temperatures[index+11].TempMin+"° C";
                  // *******************************************************
                  let jour13= document.getElementById("jour13");
         let TempDuJour13= document.getElementById("TempDuJour13");
         let TempMax13 = document.getElementById("TempMax13");
         let TempMin13 = document.getElementById("TempMin13");

         jour13.innerHTML = "Le : "+meteo.temperatures[index+12].DateDuJour;
         TempDuJour13.innerHTML ="Temp du jour: "+ meteo.temperatures[index+12].TempDuJour+"° C";
         TempMax13.innerHTML = "Max: " + meteo.temperatures[index+12].TempMax+"° C";
         TempMin13.innerHTML = "Min: " + meteo.temperatures[index+12].TempMin+"° C";
                  // *******************************************************
        let jour14= document.getElementById("jour14");
         let TempDuJour14= document.getElementById("TempDuJour14");
         let TempMax14 = document.getElementById("TempMax14");
         let TempMin14 = document.getElementById("TempMin14");

         jour14.innerHTML = "Le : "+meteo.temperatures[index+13].DateDuJour;
         TempDuJour14.innerHTML ="Temp du jour: "+ meteo.temperatures[index+13].TempDuJour+"° C";
         TempMax14.innerHTML = "Max: " + meteo.temperatures[index+13].TempMax+"° C";
         TempMin14.innerHTML = "Min: " + meteo.temperatures[index+13].TempMin+"° C";

        
      }
    }
 });
